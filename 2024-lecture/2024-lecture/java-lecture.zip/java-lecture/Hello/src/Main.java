//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        System.out.println("Hello ER");;
        // 자바는 컴파일 언어 .java .class
        // 컴파일 언어의 장점은 실행파일 만들기 전에 기본적인 오류 체크는 다 해준다
        // runtime 오류만 잘 제어하면 된다

    }
}