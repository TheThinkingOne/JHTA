package tv;


public class TvMain {
    public static void main(String[] args) {
        TV myTv = new TV("LG",2017,32);
        myTv.show();
    }
}
