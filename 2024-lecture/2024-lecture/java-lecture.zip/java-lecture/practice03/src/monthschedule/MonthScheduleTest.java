package monthschedule;

public class MonthScheduleTest {
    public static void main(String[] args) {
        MonthSchedule monthSchedule = new MonthSchedule(30); // 4월달의 30일 넣기
        monthSchedule.run();
    }
}
