package song;

import java.util.Scanner;

public class SongTest {
    public static void main(String[] args) {
        Song mySong = new Song("Welcome to the Black Parade","My Chemical Romance",2004,"영국");
        mySong.show();
    }
}
