public class A {
    public A() {
        System.out.println("나는 아인");
    }
}
