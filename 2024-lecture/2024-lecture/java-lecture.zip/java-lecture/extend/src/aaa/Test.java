package aaa;

public class Test {
    public static void main(String[] args) {
        new BBB(); // 생성자 함수 호출
        // 실행결과
        // 나는 AAA
        // 나는 BBB
        // 부모 것 먼저 호출
    }
}
