package aaa;

public class AAA {
    private int pri;
    int def;
    protected int pro;
    public int pub;

    public AAA() {
        System.out.println("나는 AAA");
    }
}
