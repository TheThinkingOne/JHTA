public class B extends A {

    public B(int num) {
        System.out.println("나는 매개변수" + num + "을 가지는 벤자민");
    }
    public B() {
        System.out.println("나는 벤자민");
    }
}
