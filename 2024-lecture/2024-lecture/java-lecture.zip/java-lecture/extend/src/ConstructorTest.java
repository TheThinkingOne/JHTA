public class ConstructorTest {
    public static void main(String[] args) {
        // class 자신을 가리키는 this
        // 부모클래스를 가리키는 super
        C carmen = new C(10);
    }
}
