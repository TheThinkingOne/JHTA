public class Converter01 extends Converter {
    @Override
    protected double convert(double srs) {
        return 0;
    }

    @Override
    protected String getSrcString() {
        return null;
    }

    @Override
    protected String getDestString() {
        return null;
    }
}
