public class RectangleTest extends Rectangle {
    public static void main(String[] args) {
        Rectangle rectangle = new Rectangle();

        rectangle.width = 10;
        rectangle.height = 20;

        System.out.println(rectangle.getArea());

        //Rectangle rectangle2 = new Rectangle2(10,20);
    }
}
