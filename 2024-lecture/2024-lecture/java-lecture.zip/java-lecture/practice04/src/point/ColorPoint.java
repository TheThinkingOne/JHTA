package point;

import tv.ColorTV;

public class ColorPoint extends Point {

    private int x; private int y;
    private String color;
    ColorPoint(int x, int y, String color) {
        super(x, y);
        this.color = color;
    }
    public void setXY(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public void setColor(String color) {
        this.color = color;
        System.out.print(color + "색의 " + "(" + x + "," + y + ")의 점입니다.");
    }


}
