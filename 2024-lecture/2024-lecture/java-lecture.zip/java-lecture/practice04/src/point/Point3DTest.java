package point;

public class Point3DTest{

    public static void main(String[] args) {
        Point3D p = new Point3D(1,2,3);
        System.out.println("초기 점의 위치는 "+p.toString()+" 입니다.");
        p.moveUp();
        System.out.println("한 칸 위로 이동한 점은 "+p.toString()+" 입니다.");
        p.moveDown();
        System.out.println("한 칸 아래로 이동한 점은 "+p.toString()+" 입니다.");
        p.move(10, 10);
        System.out.println("x,y좌표가 이동한 점은 "+p.toString()+" 입니다.");
        p.move(100, 200, 300);
        System.out.println("x,y,z좌표가 이동한 점은 "+p.toString()+" 입니다.");
    }

}
